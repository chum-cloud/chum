import { Connection, Keypair } from "@solana/web3.js";
import { config } from "dotenv";
import bs58 from "bs58";
import { AGENT_ID, DIRECTION } from "../utils/protocol.js";
import { encodeWhaleMove } from "../utils/encoder.js";
import { postToRoom } from "../utils/sender.js";

config();

// ═══════════════════════════════════════════
// WHALE WATCHER — Seed Agent #1
// ═══════════════════════════════════════════
// Monitors large wallet transactions on Solana
// Posts ALPHA to CHUM Cloud when whales move
//
// What it does:
// 1. Tracks a list of known whale wallets
// 2. Polls their recent transactions
// 3. When a whale buys/sells > threshold → post to room
//
// Other agents read these alerts and decide whether to follow

// Known whale wallets to monitor
// Add more as you discover them
const WHALE_WALLETS = process.env.WHALE_WALLETS
  ? process.env.WHALE_WALLETS.split(",")
  : [
      // These are example addresses — replace with real whales
      // You can find active whales on:
      // - birdeye.so (top traders)
      // - solscan.io (large holders)
      // - hellomooon.com (wallet tracker)
    ];

const MIN_SOL = parseInt(process.env.WHALE_MIN_SOL || "500");
const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL || "30") * 1000;
const RPC_URL = process.env.RPC_URL;

class WhaleWatcher {
  constructor() {
    this.connection = new Connection(RPC_URL, "confirmed");
    this.agentKeypair = Keypair.fromSecretKey(
      bs58.decode(process.env.WHALE_AGENT_KEY)
    );
    this.lastSignatures = new Map(); // wallet -> last seen signature
    this.agentId = AGENT_ID.WHALE_WATCHER;

    console.log(
      `[WHALE] Agent wallet: ${this.agentKeypair.publicKey.toBase58()}`
    );
    console.log(`[WHALE] Monitoring ${WHALE_WALLETS.length} whale wallets`);
    console.log(`[WHALE] Min threshold: ${MIN_SOL} SOL`);
  }

  /**
   * Check a whale wallet for recent large transactions
   */
  async checkWallet(walletAddress) {
    try {
      const opts = { limit: 5 };
      const lastSig = this.lastSignatures.get(walletAddress);
      if (lastSig) {
        opts.until = lastSig;
      }

      const signatures = await this.connection.getSignaturesForAddress(
        walletAddress,
        opts
      );

      if (signatures.length === 0) return;

      // Update cursor
      if (!lastSig) {
        // First check — just set cursor, don't alert on old txs
        this.lastSignatures.set(walletAddress, signatures[0].signature);
        return;
      }

      this.lastSignatures.set(walletAddress, signatures[0].signature);

      // Check each new transaction
      for (const sigInfo of signatures) {
        await this.analyzeTx(sigInfo.signature, walletAddress);
      }
    } catch (err) {
      console.error(`[WHALE] Error checking ${walletAddress}: ${err.message}`);
    }
  }

  /**
   * Analyze a transaction to determine if it's a significant whale move
   */
  async analyzeTx(signature, walletAddress) {
    try {
      const tx = await this.connection.getTransaction(signature, {
        commitment: "confirmed",
        maxSupportedTransactionVersion: 0,
      });

      if (!tx || !tx.meta || tx.meta.err) return;

      // Calculate SOL balance change for the whale
      const accountKeys =
        tx.transaction.message.staticAccountKeys ||
        tx.transaction.message.accountKeys;

      const walletIndex = accountKeys.findIndex(
        (key) => key.toBase58() === walletAddress
      );

      if (walletIndex === -1) return;

      const preBalance = tx.meta.preBalances[walletIndex];
      const postBalance = tx.meta.postBalances[walletIndex];
      const changeLamports = postBalance - preBalance;
      const changeSol = Math.abs(changeLamports) / 1e9;

      // Only alert on moves above threshold
      if (changeSol < MIN_SOL) return;

      const direction =
        changeLamports > 0 ? DIRECTION.BULLISH : DIRECTION.BEARISH;

      // Detect token transfers (SPL token balance changes)
      let tokenMint = "So11111111111111111111111111111111111111112"; // native SOL default
      if (tx.meta.preTokenBalances && tx.meta.postTokenBalances) {
        // Find the most significant token balance change
        for (const post of tx.meta.postTokenBalances) {
          if (post.owner === walletAddress) {
            const pre = tx.meta.preTokenBalances.find(
              (p) => p.accountIndex === post.accountIndex
            );
            if (pre) {
              const tokenChange = Math.abs(
                (post.uiTokenAmount?.uiAmount || 0) -
                  (pre.uiTokenAmount?.uiAmount || 0)
              );
              if (tokenChange > 0) {
                tokenMint = post.mint;
                break;
              }
            }
          }
        }
      }

      console.log(
        `[WHALE] 🐋 Detected! ${walletAddress.slice(0, 8)}... moved ${changeSol.toFixed(2)} SOL (${direction === DIRECTION.BULLISH ? "IN" : "OUT"})`
      );

      // Encode and post to CHUM Cloud
      const memo = encodeWhaleMove(this.agentId, {
        direction,
        tokenMint,
        amountLamports: Math.abs(changeLamports),
        whaleWallet: walletAddress,
        txSignature: signature,
        timestamp: tx.blockTime || Math.floor(Date.now() / 1000),
      });

      await postToRoom(this.connection, this.agentKeypair, memo);
    } catch (err) {
      console.error(`[WHALE] Error analyzing tx: ${err.message}`);
    }
  }

  /**
   * Main loop — poll all whale wallets
   */
  async run() {
    console.log(`[WHALE] 🐋 Whale Watcher starting...`);
    console.log(`[WHALE] Posting to CHUM Cloud room`);
    console.log(`[WHALE] Poll interval: ${POLL_INTERVAL / 1000}s\n`);

    if (WHALE_WALLETS.length === 0) {
      console.log(`[WHALE] ⚠️  No whale wallets configured!`);
      console.log(`[WHALE] Add wallets to WHALE_WALLETS in .env`);
      console.log(`[WHALE] Find whales at birdeye.so or solscan.io`);
      return;
    }

    // Initial scan to set cursors
    console.log(`[WHALE] Initial scan...`);
    for (const wallet of WHALE_WALLETS) {
      await this.checkWallet(wallet);
      await sleep(200); // rate limit friendly
    }
    console.log(`[WHALE] Cursors set. Watching for new moves...\n`);

    // Poll loop
    while (true) {
      for (const wallet of WHALE_WALLETS) {
        await this.checkWallet(wallet);
        await sleep(200);
      }
      await sleep(POLL_INTERVAL);
    }
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Run
const watcher = new WhaleWatcher();
watcher.run().catch(console.error);
