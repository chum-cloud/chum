import { Connection, Keypair } from "@solana/web3.js";
import { config } from "dotenv";
import bs58 from "bs58";
import { AGENT_ID, DIRECTION } from "../utils/protocol.js";
import { encodePriceMomentum } from "../utils/encoder.js";
import { postToRoom } from "../utils/sender.js";

config();

// ═══════════════════════════════════════════
// PRICE MOMENTUM TRACKER — Seed Agent #3
// ═══════════════════════════════════════════
// Tracks token prices and detects strong momentum moves
// Posts ALPHA when tokens move significantly in short time
//
// How it works:
// 1. Polls token prices every interval
// 2. Compares to price N minutes ago
// 3. If change > threshold → momentum detected → post to room
// 4. Calculates momentum score based on speed + magnitude

const LOOKBACK_MINUTES = parseInt(
  process.env.MOMENTUM_LOOKBACK_MINUTES || "15"
);
const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL || "30") * 1000;
const RPC_URL = process.env.RPC_URL;

// Momentum thresholds (in basis points)
// 500 bps = 5% move
const MOMENTUM_THRESHOLD_BPS = 300; // 3% move triggers alert

// Tokens to track momentum for
const WATCH_TOKENS = [
  {
    symbol: "SOL",
    mint: "So11111111111111111111111111111111111111112",
  },
  {
    symbol: "BONK",
    mint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  },
  {
    symbol: "WIF",
    mint: "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",
  },
  {
    symbol: "JUP",
    mint: "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
  },
  {
    symbol: "RAY",
    mint: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
  },
  {
    symbol: "ORCA",
    mint: "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",
  },
  {
    symbol: "PYTH",
    mint: "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
  },
  {
    symbol: "JTO",
    mint: "jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL",
  },
];

class PriceMomentumTracker {
  constructor() {
    this.connection = new Connection(RPC_URL, "confirmed");
    this.agentKeypair = Keypair.fromSecretKey(
      bs58.decode(process.env.MOMENTUM_AGENT_KEY)
    );
    this.agentId = AGENT_ID.MOMENTUM_TRACKER;

    // Price history: mint -> [{price, timestamp}]
    this.priceHistory = new Map();
    // Track which moves we already reported (avoid spam)
    this.reportedMoves = new Map(); // mint -> lastReportedTimestamp

    console.log(
      `[MOMENTUM] Agent wallet: ${this.agentKeypair.publicKey.toBase58()}`
    );
    console.log(`[MOMENTUM] Watching ${WATCH_TOKENS.length} tokens`);
    console.log(`[MOMENTUM] Lookback: ${LOOKBACK_MINUTES} minutes`);
    console.log(`[MOMENTUM] Threshold: ${MOMENTUM_THRESHOLD_BPS} bps (${MOMENTUM_THRESHOLD_BPS / 100}%)`);
  }

  /**
   * Fetch current price using Jupiter Price API (free)
   */
  async fetchPrices() {
    try {
      const mints = WATCH_TOKENS.map((t) => t.mint).join(",");
      const resp = await fetch(`https://api.jup.ag/price/v2?ids=${mints}`);
      const data = await resp.json();

      const prices = {};
      for (const token of WATCH_TOKENS) {
        const tokenData = data.data?.[token.mint];
        if (tokenData) {
          prices[token.mint] = {
            price: parseFloat(tokenData.price),
            symbol: token.symbol,
            timestamp: Math.floor(Date.now() / 1000),
          };
        }
      }
      return prices;
    } catch (err) {
      console.error(`[MOMENTUM] Error fetching prices: ${err.message}`);
      return {};
    }
  }

  /**
   * Record price snapshot
   */
  recordPrice(mint, price, timestamp) {
    const history = this.priceHistory.get(mint) || [];
    history.push({ price, timestamp });

    // Keep only lookback window + buffer
    const cutoff = timestamp - LOOKBACK_MINUTES * 60 * 2;
    const trimmed = history.filter((h) => h.timestamp >= cutoff);

    this.priceHistory.set(mint, trimmed);
  }

  /**
   * Calculate momentum for a token
   */
  calculateMomentum(mint, currentPrice, currentTimestamp) {
    const history = this.priceHistory.get(mint) || [];

    if (history.length < 2) {
      return null;
    }

    // Find price at lookback time
    const lookbackTime = currentTimestamp - LOOKBACK_MINUTES * 60;
    let closestEntry = null;
    let closestDiff = Infinity;

    for (const entry of history) {
      const diff = Math.abs(entry.timestamp - lookbackTime);
      if (diff < closestDiff) {
        closestDiff = diff;
        closestEntry = entry;
      }
    }

    if (!closestEntry || closestDiff > LOOKBACK_MINUTES * 60) {
      return null; // No data close enough to lookback time
    }

    const priceBefore = closestEntry.price;
    if (priceBefore === 0) return null;

    const changeBps = Math.round(
      ((currentPrice - priceBefore) / priceBefore) * 10000
    );
    const absChangeBps = Math.abs(changeBps);

    // Momentum score: combines magnitude and speed
    // Higher = more significant move
    // Scale: 0-10000
    const magnitude = Math.min(absChangeBps * 2, 5000); // cap at 5000
    const speed = Math.min(
      (absChangeBps / (LOOKBACK_MINUTES / 5)) * 100,
      5000
    ); // normalized
    const momentumScore = Math.min(Math.round((magnitude + speed) / 2), 10000);

    const direction =
      changeBps > 0
        ? DIRECTION.BULLISH
        : changeBps < 0
          ? DIRECTION.BEARISH
          : DIRECTION.NEUTRAL;

    return {
      priceBefore,
      priceNow: currentPrice,
      changeBps,
      absChangeBps,
      momentumScore,
      direction,
      lookbackSeconds: LOOKBACK_MINUTES * 60,
    };
  }

  /**
   * Check if we should report this move (avoid spam)
   * Don't report the same direction for same token within 10 minutes
   */
  shouldReport(mint, direction) {
    const key = `${mint}_${direction}`;
    const lastReported = this.reportedMoves.get(key);
    const now = Math.floor(Date.now() / 1000);

    if (lastReported && now - lastReported < 600) {
      return false; // Already reported within 10 min
    }

    this.reportedMoves.set(key, now);
    return true;
  }

  /**
   * Scan all tokens for momentum
   */
  async scan() {
    const prices = await this.fetchPrices();
    const now = Math.floor(Date.now() / 1000);

    for (const token of WATCH_TOKENS) {
      const priceData = prices[token.mint];
      if (!priceData) continue;

      // Record current price
      this.recordPrice(token.mint, priceData.price, now);

      // Calculate momentum
      const momentum = this.calculateMomentum(
        token.mint,
        priceData.price,
        now
      );

      if (!momentum) continue;

      // Check if significant
      if (momentum.absChangeBps >= MOMENTUM_THRESHOLD_BPS) {
        // Check if we already reported this
        if (!this.shouldReport(token.mint, momentum.direction)) {
          continue;
        }

        const dirStr = momentum.direction === DIRECTION.BULLISH ? "🟢" : "🔴";
        console.log(
          `[MOMENTUM] ${dirStr} ${token.symbol}: ${(momentum.changeBps / 100).toFixed(2)}% in ${LOOKBACK_MINUTES}min | score: ${momentum.momentumScore}`
        );

        // Convert price to lamport-scale integer for encoding
        // We store as u64 with 9 decimal precision
        const priceNowLamports = BigInt(
          Math.round(priceData.price * 1e9)
        );
        const priceBeforeLamports = BigInt(
          Math.round(momentum.priceBefore * 1e9)
        );

        // Post to CHUM Cloud
        const memo = encodePriceMomentum(this.agentId, {
          direction: momentum.direction,
          tokenMint: token.mint,
          priceNow: priceNowLamports,
          priceBefore: priceBeforeLamports,
          changeBps: momentum.changeBps,
          momentumScore: momentum.momentumScore,
          lookbackSeconds: momentum.lookbackSeconds,
          timestamp: now,
        });

        await postToRoom(this.connection, this.agentKeypair, memo);
      }
    }
  }

  /**
   * Main loop
   */
  async run() {
    console.log(`[MOMENTUM] 📈 Price Momentum Tracker starting...`);
    console.log(`[MOMENTUM] Posting to CHUM Cloud room`);
    console.log(`[MOMENTUM] Poll interval: ${POLL_INTERVAL / 1000}s`);
    console.log(
      `[MOMENTUM] Building price history (${LOOKBACK_MINUTES} min)...\n`
    );

    // Build initial price history
    // Need at least a few data points before we can detect momentum
    console.log(`[MOMENTUM] Collecting initial prices...`);
    for (let i = 0; i < 3; i++) {
      await this.scan();
      if (i < 2) {
        console.log(
          `[MOMENTUM] Snapshot ${i + 1}/3... waiting ${POLL_INTERVAL / 1000}s`
        );
        await sleep(POLL_INTERVAL);
      }
    }
    console.log(`[MOMENTUM] History established. Watching for momentum...\n`);

    // Main poll loop
    while (true) {
      await this.scan();
      await sleep(POLL_INTERVAL);
    }
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const tracker = new PriceMomentumTracker();
tracker.run().catch(console.error);
