import { Connection, Keypair } from "@solana/web3.js";
import { config } from "dotenv";
import bs58 from "bs58";
import { AGENT_ID, DIRECTION } from "../utils/protocol.js";
import { encodeVolumeSpike } from "../utils/encoder.js";
import { postToRoom } from "../utils/sender.js";

config();

// ═══════════════════════════════════════════
// VOLUME SPIKE DETECTOR — Seed Agent #2
// ═══════════════════════════════════════════
// Monitors token trading volume on Jupiter/Raydium
// Posts ALPHA when volume spikes above normal
//
// How it works:
// 1. Tracks rolling average volume for watched tokens
// 2. Compares current period to average
// 3. If current > N × average → spike detected → post to room
//
// Uses Birdeye or Jupiter API for volume data

const SPIKE_MULTIPLIER = parseFloat(
  process.env.VOLUME_SPIKE_MULTIPLIER || "3"
);
const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL || "30") * 1000;
const RPC_URL = process.env.RPC_URL;
const PERIOD_SECONDS = 300; // 5 minute periods

// Tokens to watch for volume spikes
// Start with major tokens, expand over time
const WATCH_TOKENS = [
  {
    symbol: "SOL",
    mint: "So11111111111111111111111111111111111111112",
  },
  {
    symbol: "BONK",
    mint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  },
  {
    symbol: "WIF",
    mint: "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",
  },
  {
    symbol: "JUP",
    mint: "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
  },
  {
    symbol: "RAY",
    mint: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
  },
  {
    symbol: "ORCA",
    mint: "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",
  },
];

class VolumeSpikeDetector {
  constructor() {
    this.connection = new Connection(RPC_URL, "confirmed");
    this.agentKeypair = Keypair.fromSecretKey(
      bs58.decode(process.env.VOLUME_AGENT_KEY)
    );
    this.agentId = AGENT_ID.VOLUME_SCANNER;

    // Rolling volume history: mint -> [volumes]
    this.volumeHistory = new Map();
    // How many periods to track for average
    this.historyLength = 12; // 12 × 5min = 1 hour rolling average

    console.log(
      `[VOLUME] Agent wallet: ${this.agentKeypair.publicKey.toBase58()}`
    );
    console.log(`[VOLUME] Watching ${WATCH_TOKENS.length} tokens`);
    console.log(`[VOLUME] Spike threshold: ${SPIKE_MULTIPLIER}x`);
  }

  /**
   * Fetch current volume for a token
   * Uses Jupiter price API which includes volume data
   *
   * In production, you'd use:
   * - Birdeye API: https://public-api.birdeye.so/defi/token_overview
   * - Jupiter Stats API
   * - Direct DEX monitoring via getProgramAccounts
   */
  async fetchVolume(tokenMint) {
    try {
      // Method 1: Use Birdeye API (recommended, needs API key)
      // const resp = await fetch(
      //   `https://public-api.birdeye.so/defi/token_overview?address=${tokenMint}`,
      //   { headers: { "X-API-KEY": process.env.BIRDEYE_API_KEY } }
      // );
      // const data = await resp.json();
      // return data.data?.v24hUSD || 0;

      // Method 2: Use Jupiter price API (free, simpler)
      const resp = await fetch(
        `https://api.jup.ag/price/v2?ids=${tokenMint}&showExtraInfo=true`
      );
      const data = await resp.json();
      const tokenData = data.data?.[tokenMint];

      if (!tokenData) return null;

      return {
        price: parseFloat(tokenData.price || 0),
        // Jupiter doesn't directly give volume, but we can
        // estimate from on-chain activity. For production,
        // use Birdeye API which gives proper volume data.
        // For now, we track price changes as a proxy.
        volume: parseFloat(tokenData.extraInfo?.quotedPrice?.buyPrice || 0),
      };
    } catch (err) {
      console.error(
        `[VOLUME] Error fetching volume for ${tokenMint}: ${err.message}`
      );
      return null;
    }
  }

  /**
   * Alternative: Estimate volume by counting recent swap transactions
   * This works without any external API — pure RPC
   */
  async estimateVolumeFromChain(tokenMint) {
    try {
      // Get recent signatures for the token mint account
      const signatures = await this.connection.getSignaturesForAddress(
        tokenMint,
        { limit: 50 }
      );

      // Count transactions in the last PERIOD_SECONDS
      const now = Math.floor(Date.now() / 1000);
      const cutoff = now - PERIOD_SECONDS;

      let txCount = 0;
      for (const sig of signatures) {
        if (sig.blockTime && sig.blockTime >= cutoff) {
          txCount++;
        }
      }

      return {
        txCount,
        period: PERIOD_SECONDS,
        // Use tx count as volume proxy
        // More txs = more activity = potential spike
        volume: txCount,
      };
    } catch (err) {
      return { txCount: 0, period: PERIOD_SECONDS, volume: 0 };
    }
  }

  /**
   * Check if current volume represents a spike
   */
  checkSpike(tokenMint, currentVolume) {
    const history = this.volumeHistory.get(tokenMint) || [];

    // Need at least 3 periods for meaningful average
    if (history.length < 3) {
      return { isSpike: false, multiplier: 0, avg: 0 };
    }

    const avg = history.reduce((a, b) => a + b, 0) / history.length;

    if (avg === 0) {
      return { isSpike: false, multiplier: 0, avg: 0 };
    }

    const multiplier = currentVolume / avg;

    return {
      isSpike: multiplier >= SPIKE_MULTIPLIER,
      multiplier: Math.round(multiplier * 100), // stored as u16, 300 = 3x
      avg: Math.round(avg),
    };
  }

  /**
   * Update rolling volume history
   */
  updateHistory(tokenMint, volume) {
    const history = this.volumeHistory.get(tokenMint) || [];
    history.push(volume);

    // Keep only recent periods
    if (history.length > this.historyLength) {
      history.shift();
    }

    this.volumeHistory.set(tokenMint, history);
  }

  /**
   * Scan all watched tokens for volume spikes
   */
  async scan() {
    for (const token of WATCH_TOKENS) {
      try {
        // Use on-chain estimation (free, no API key needed)
        const data = await this.estimateVolumeFromChain(token.mint);
        const currentVolume = data.volume;

        // Check for spike
        const spike = this.checkSpike(token.mint, currentVolume);

        if (spike.isSpike) {
          console.log(
            `[VOLUME] 📈 SPIKE! ${token.symbol}: ${(spike.multiplier / 100).toFixed(1)}x normal volume!`
          );

          // Determine direction based on trend
          const history = this.volumeHistory.get(token.mint) || [];
          const recentTrend =
            history.length >= 2
              ? history[history.length - 1] - history[history.length - 2]
              : 0;
          const direction =
            recentTrend > 0 ? DIRECTION.BULLISH : DIRECTION.BEARISH;

          // Post to CHUM Cloud
          const memo = encodeVolumeSpike(this.agentId, {
            direction,
            tokenMint: token.mint,
            currentVolume: BigInt(currentVolume),
            avgVolume: BigInt(spike.avg),
            spikeMultiplier: spike.multiplier,
            periodSeconds: PERIOD_SECONDS,
            timestamp: Math.floor(Date.now() / 1000),
          });

          await postToRoom(this.connection, this.agentKeypair, memo);
        }

        // Update history
        this.updateHistory(token.mint, currentVolume);

        await sleep(500); // rate limit
      } catch (err) {
        console.error(
          `[VOLUME] Error scanning ${token.symbol}: ${err.message}`
        );
      }
    }
  }

  /**
   * Main loop
   */
  async run() {
    console.log(`[VOLUME] 📊 Volume Spike Detector starting...`);
    console.log(`[VOLUME] Posting to CHUM Cloud room`);
    console.log(`[VOLUME] Poll interval: ${POLL_INTERVAL / 1000}s`);
    console.log(`[VOLUME] Period: ${PERIOD_SECONDS}s`);
    console.log(
      `[VOLUME] Building volume baseline (${this.historyLength} periods)...\n`
    );

    // Build initial baseline
    for (let i = 0; i < 3; i++) {
      console.log(`[VOLUME] Baseline scan ${i + 1}/3...`);
      await this.scan();
      if (i < 2) await sleep(PERIOD_SECONDS * 1000);
    }
    console.log(`[VOLUME] Baseline established. Watching for spikes...\n`);

    // Main poll loop
    while (true) {
      await this.scan();
      await sleep(POLL_INTERVAL);
    }
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const detector = new VolumeSpikeDetector();
detector.run().catch(console.error);
