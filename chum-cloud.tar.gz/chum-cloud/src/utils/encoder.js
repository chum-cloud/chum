import { PublicKey } from "@solana/web3.js";
import {
  CHUM_MAGIC,
  PROTOCOL_VERSION,
  MSG_TYPE,
  ALPHA_TYPE,
  DIRECTION,
} from "./protocol.js";

// ═══════════════════════════════════════════
// ENCODER — Builds binary memo payloads
// ═══════════════════════════════════════════
// All messages start with the CHUM header:
// [0x43, 0x48, version, msg_type, agent_id, ...]
// "CH" magic bytes let any agent identify CHUM messages

/**
 * Build the standard CHUM header
 */
function buildHeader(msgType, agentId) {
  return Buffer.from([
    CHUM_MAGIC[0], // 0x43 "C"
    CHUM_MAGIC[1], // 0x48 "H"
    PROTOCOL_VERSION, // version
    msgType, // message type
    agentId, // which agent
  ]);
}

/**
 * Encode a u64 as 8 bytes (little-endian)
 */
function encodeU64(value) {
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64LE(BigInt(value));
  return buf;
}

/**
 * Encode an i64 as 8 bytes (little-endian)
 */
function encodeI64(value) {
  const buf = Buffer.alloc(8);
  buf.writeBigInt64LE(BigInt(value));
  return buf;
}

/**
 * Encode a string into fixed-length bytes (padded/truncated)
 */
function encodeString(str, length) {
  const buf = Buffer.alloc(length);
  buf.write(str.slice(0, length), "utf8");
  return buf;
}

// ═══════════════════════════════════════════
// ALPHA MESSAGE ENCODERS
// ═══════════════════════════════════════════

/**
 * Encode WHALE MOVE alpha
 *
 * Layout (after 5-byte header):
 * [5]      alpha_type: u8 (WHALE_MOVE = 0x01)
 * [6]      direction: u8 (buy/sell/neutral)
 * [7..39]  token_mint: 32 bytes (Pubkey)
 * [39..47] amount_sol: u64 (in lamports)
 * [47..79] whale_wallet: 32 bytes (Pubkey, first 32 of address)
 * [79..87] timestamp: i64
 * [87..119] tx_signature: 32 bytes (first 32 bytes of sig)
 */
export function encodeWhaleMove(agentId, data) {
  const header = buildHeader(MSG_TYPE.ALPHA, agentId);
  const body = Buffer.concat([
    Buffer.from([ALPHA_TYPE.WHALE_MOVE]),
    Buffer.from([data.direction]),
    new PublicKey(data.tokenMint).toBuffer(),
    encodeU64(data.amountLamports),
    new PublicKey(data.whaleWallet).toBuffer(),
    encodeI64(data.timestamp || Math.floor(Date.now() / 1000)),
    encodeString(data.txSignature || "", 32),
  ]);

  return Buffer.concat([header, body]);
}

/**
 * Encode VOLUME SPIKE alpha
 *
 * Layout (after 5-byte header):
 * [5]      alpha_type: u8 (VOLUME_SPIKE = 0x02)
 * [6]      direction: u8
 * [7..39]  token_mint: 32 bytes
 * [39..47] current_volume: u64 (lamports, last period)
 * [47..55] avg_volume: u64 (lamports, avg period)
 * [55..57] spike_multiplier: u16 (100 = 1x, 300 = 3x)
 * [57..65] period_seconds: u64 (the time window measured)
 * [65..73] timestamp: i64
 */
export function encodeVolumeSpike(agentId, data) {
  const header = buildHeader(MSG_TYPE.ALPHA, agentId);

  const multiplierBuf = Buffer.alloc(2);
  multiplierBuf.writeUInt16LE(data.spikeMultiplier); // e.g. 300 = 3x

  const body = Buffer.concat([
    Buffer.from([ALPHA_TYPE.VOLUME_SPIKE]),
    Buffer.from([data.direction]),
    new PublicKey(data.tokenMint).toBuffer(),
    encodeU64(data.currentVolume),
    encodeU64(data.avgVolume),
    multiplierBuf,
    encodeU64(data.periodSeconds),
    encodeI64(data.timestamp || Math.floor(Date.now() / 1000)),
  ]);

  return Buffer.concat([header, body]);
}

/**
 * Encode PRICE MOMENTUM alpha
 *
 * Layout (after 5-byte header):
 * [5]      alpha_type: u8 (PRICE_MOMENTUM = 0x03)
 * [6]      direction: u8
 * [7..39]  token_mint: 32 bytes
 * [39..47] price_now: u64 (in smallest unit / lamports)
 * [47..55] price_before: u64 (price at lookback start)
 * [55..57] change_bps: i16 (basis points, e.g. 500 = +5%)
 * [57..59] momentum_score: u16 (0-10000)
 * [59..67] lookback_seconds: u64
 * [67..75] timestamp: i64
 */
export function encodePriceMomentum(agentId, data) {
  const header = buildHeader(MSG_TYPE.ALPHA, agentId);

  const changeBuf = Buffer.alloc(2);
  changeBuf.writeInt16LE(data.changeBps);

  const momentumBuf = Buffer.alloc(2);
  momentumBuf.writeUInt16LE(data.momentumScore);

  const body = Buffer.concat([
    Buffer.from([ALPHA_TYPE.PRICE_MOMENTUM]),
    Buffer.from([data.direction]),
    new PublicKey(data.tokenMint).toBuffer(),
    encodeU64(data.priceNow),
    encodeU64(data.priceBefore),
    changeBuf,
    momentumBuf,
    encodeU64(data.lookbackSeconds),
    encodeI64(data.timestamp || Math.floor(Date.now() / 1000)),
  ]);

  return Buffer.concat([header, body]);
}

// ═══════════════════════════════════════════
// SIGNAL MESSAGE ENCODER
// ═══════════════════════════════════════════

/**
 * Encode a SIGNAL (processed analysis)
 *
 * Layout (after 5-byte header):
 * [5..37]  token_mint: 32 bytes
 * [37]     sentiment: u8 (0-100)
 * [38]     momentum: u8 (0-100)
 * [39]     risk: u8 (0-100)
 * [40]     confidence: u8 (0-100)
 * [41..49] price_now: u64
 * [49..57] price_target: u64
 * [57..65] timeframe_seconds: u64
 * [65..73] timestamp: i64
 */
export function encodeSignal(agentId, data) {
  const header = buildHeader(MSG_TYPE.SIGNAL, agentId);
  const body = Buffer.concat([
    new PublicKey(data.tokenMint).toBuffer(),
    Buffer.from([data.sentiment]),
    Buffer.from([data.momentum]),
    Buffer.from([data.risk]),
    Buffer.from([data.confidence]),
    encodeU64(data.priceNow),
    encodeU64(data.priceTarget),
    encodeU64(data.timeframeSeconds),
    encodeI64(data.timestamp || Math.floor(Date.now() / 1000)),
  ]);

  return Buffer.concat([header, body]);
}

// ═══════════════════════════════════════════
// RALLY MESSAGE ENCODER
// ═══════════════════════════════════════════

/**
 * Encode a RALLY (coordination call)
 *
 * Layout (after 5-byte header):
 * [5..37]  token_mint: 32 bytes
 * [37]     action: u8 (0=buy 1=sell)
 * [38..46] entry_price: u64
 * [46..54] target_price: u64
 * [54..62] stop_price: u64
 * [62..70] start_time: i64
 * [70..78] max_duration_seconds: u64
 * [78..86] rally_id: u64
 * [86..94] timestamp: i64
 */
export function encodeRally(agentId, data) {
  const header = buildHeader(MSG_TYPE.RALLY, agentId);
  const body = Buffer.concat([
    new PublicKey(data.tokenMint).toBuffer(),
    Buffer.from([data.action]), // 0=buy, 1=sell
    encodeU64(data.entryPrice),
    encodeU64(data.targetPrice),
    encodeU64(data.stopPrice),
    encodeI64(data.startTime),
    encodeU64(data.maxDurationSeconds),
    encodeU64(data.rallyId),
    encodeI64(data.timestamp || Math.floor(Date.now() / 1000)),
  ]);

  return Buffer.concat([header, body]);
}

// ═══════════════════════════════════════════
// EXIT MESSAGE ENCODER
// ═══════════════════════════════════════════

/**
 * Encode an EXIT signal
 *
 * Layout (after 5-byte header):
 * [5..13]  rally_id: u64
 * [13]     exit_type: u8 (0=target 1=stop 2=time 3=manual)
 * [14..22] exit_price: u64
 * [22..30] timestamp: i64
 */
export function encodeExit(agentId, data) {
  const header = buildHeader(MSG_TYPE.EXIT, agentId);
  const body = Buffer.concat([
    encodeU64(data.rallyId),
    Buffer.from([data.exitType]),
    encodeU64(data.exitPrice),
    encodeI64(data.timestamp || Math.floor(Date.now() / 1000)),
  ]);

  return Buffer.concat([header, body]);
}

// ═══════════════════════════════════════════
// RESULT MESSAGE ENCODER
// ═══════════════════════════════════════════

/**
 * Encode a RESULT (post-trade scorecard)
 *
 * Layout (after 5-byte header):
 * [5..13]  rally_id: u64
 * [13..45] token_mint: 32 bytes
 * [45..53] entry_price: u64
 * [53..61] exit_price: u64
 * [61]     outcome: u8 (0=win 1=loss 2=breakeven)
 * [62..64] pnl_bps: i16
 * [64]     participants: u8
 * [65..73] duration_seconds: u64
 * [73..81] timestamp: i64
 */
export function encodeResult(agentId, data) {
  const header = buildHeader(MSG_TYPE.RESULT, agentId);

  const pnlBuf = Buffer.alloc(2);
  pnlBuf.writeInt16LE(data.pnlBps);

  const body = Buffer.concat([
    encodeU64(data.rallyId),
    new PublicKey(data.tokenMint).toBuffer(),
    encodeU64(data.entryPrice),
    encodeU64(data.exitPrice),
    Buffer.from([data.outcome]),
    pnlBuf,
    Buffer.from([data.participants]),
    encodeU64(data.durationSeconds),
    encodeI64(data.timestamp || Math.floor(Date.now() / 1000)),
  ]);

  return Buffer.concat([header, body]);
}
