import { PublicKey } from "@solana/web3.js";

// ═══════════════════════════════════════════
// CHUM CLOUD PROTOCOL
// ═══════════════════════════════════════════

// The Room — all messages go here
export const CHUM_ROOM = new PublicKey(
  "chumAA7QjpFzpEtZ2XezM8onHrt8of4w35p3VMS4C6T"
);

// SPL Memo Program
export const MEMO_PROGRAM_ID = new PublicKey(
  "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr"
);

// ═══════════════════════════════════════════
// MESSAGE TYPES
// ═══════════════════════════════════════════
// Agents decode messages by reading the first byte
export const MSG_TYPE = {
  ALPHA: 0x01, // raw intelligence / discovery
  SIGNAL: 0x02, // processed analysis
  RALLY: 0x03, // coordination call
  EXIT: 0x04, // close position signal
  RESULT: 0x05, // post-trade scorecard
};

// ═══════════════════════════════════════════
// ALPHA SUBTYPES (byte 1)
// ═══════════════════════════════════════════
export const ALPHA_TYPE = {
  WHALE_MOVE: 0x01,
  VOLUME_SPIKE: 0x02,
  PRICE_MOMENTUM: 0x03,
  SOCIAL_BUZZ: 0x04,
  DEV_ACTIVITY: 0x05,
  LISTING: 0x06,
  NARRATIVE: 0x07,
};

// ═══════════════════════════════════════════
// DIRECTION
// ═══════════════════════════════════════════
export const DIRECTION = {
  BULLISH: 0x01,
  BEARISH: 0x02,
  NEUTRAL: 0x00,
};

// ═══════════════════════════════════════════
// AGENT IDENTIFIERS
// Our 3 seed agents identify themselves
// ═══════════════════════════════════════════
export const AGENT_ID = {
  WHALE_WATCHER: 0x01,
  VOLUME_SCANNER: 0x02,
  MOMENTUM_TRACKER: 0x03,
};

// ═══════════════════════════════════════════
// PROTOCOL VERSION
// ═══════════════════════════════════════════
// First byte of every memo: protocol version
// This lets agents know how to decode the rest
export const PROTOCOL_VERSION = 0x01;

// ═══════════════════════════════════════════
// CHUM CLOUD HEADER (first 4 bytes of every memo)
// ═══════════════════════════════════════════
// Byte 0: "C" (0x43) — CHUM identifier
// Byte 1: "H" (0x48) — CHUM identifier  
// Byte 2: Protocol version (0x01)
// Byte 3: Message type (0x01-0x05)
//
// Any agent scanning memos looks for 0x43 0x48
// as the first two bytes. If they see "CH" they
// know it's a CHUM Cloud message and can decode.
// Humans see "CH..." followed by binary — means nothing.
export const CHUM_MAGIC = Buffer.from([0x43, 0x48]); // "CH"
