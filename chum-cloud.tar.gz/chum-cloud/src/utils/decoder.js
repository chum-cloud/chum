import { PublicKey } from "@solana/web3.js";
import {
  CHUM_MAGIC,
  MSG_TYPE,
  ALPHA_TYPE,
  DIRECTION,
  AGENT_ID,
} from "./protocol.js";

// ═══════════════════════════════════════════
// DECODER — Parses binary memo payloads
// ═══════════════════════════════════════════
// Any agent that knows the CHUM protocol can decode.
// Humans see hex noise on Solana Explorer.

// Lookup maps for human-readable output
const MSG_TYPE_NAME = {
  [MSG_TYPE.ALPHA]: "ALPHA",
  [MSG_TYPE.SIGNAL]: "SIGNAL",
  [MSG_TYPE.RALLY]: "RALLY",
  [MSG_TYPE.EXIT]: "EXIT",
  [MSG_TYPE.RESULT]: "RESULT",
};

const ALPHA_TYPE_NAME = {
  [ALPHA_TYPE.WHALE_MOVE]: "WHALE_MOVE",
  [ALPHA_TYPE.VOLUME_SPIKE]: "VOLUME_SPIKE",
  [ALPHA_TYPE.PRICE_MOMENTUM]: "PRICE_MOMENTUM",
  [ALPHA_TYPE.SOCIAL_BUZZ]: "SOCIAL_BUZZ",
  [ALPHA_TYPE.DEV_ACTIVITY]: "DEV_ACTIVITY",
  [ALPHA_TYPE.LISTING]: "LISTING",
  [ALPHA_TYPE.NARRATIVE]: "NARRATIVE",
};

const DIRECTION_NAME = {
  [DIRECTION.BULLISH]: "BULLISH",
  [DIRECTION.BEARISH]: "BEARISH",
  [DIRECTION.NEUTRAL]: "NEUTRAL",
};

const AGENT_NAME = {
  [AGENT_ID.WHALE_WATCHER]: "WHALE_WATCHER",
  [AGENT_ID.VOLUME_SCANNER]: "VOLUME_SCANNER",
  [AGENT_ID.MOMENTUM_TRACKER]: "MOMENTUM_TRACKER",
};

/**
 * Check if a memo buffer is a CHUM Cloud message
 */
export function isChumMessage(data) {
  if (!Buffer.isBuffer(data)) {
    data = Buffer.from(data);
  }
  return data.length >= 5 && data[0] === CHUM_MAGIC[0] && data[1] === CHUM_MAGIC[1];
}

/**
 * Decode any CHUM Cloud message
 * Returns structured object with all fields
 */
export function decode(data) {
  if (!Buffer.isBuffer(data)) {
    data = Buffer.from(data);
  }

  if (!isChumMessage(data)) {
    return null;
  }

  const version = data[2];
  const msgType = data[3];
  const agentId = data[4];

  const base = {
    version,
    msgType,
    msgTypeName: MSG_TYPE_NAME[msgType] || "UNKNOWN",
    agentId,
    agentName: AGENT_NAME[agentId] || `AGENT_${agentId}`,
  };

  switch (msgType) {
    case MSG_TYPE.ALPHA:
      return decodeAlpha(data, base);
    case MSG_TYPE.SIGNAL:
      return decodeSignal(data, base);
    case MSG_TYPE.RALLY:
      return decodeRally(data, base);
    case MSG_TYPE.EXIT:
      return decodeExit(data, base);
    case MSG_TYPE.RESULT:
      return decodeResult(data, base);
    default:
      return { ...base, raw: data.toString("hex") };
  }
}

/**
 * Decode ALPHA message
 */
function decodeAlpha(data, base) {
  const alphaType = data[5];

  switch (alphaType) {
    case ALPHA_TYPE.WHALE_MOVE:
      return decodeWhaleMove(data, base);
    case ALPHA_TYPE.VOLUME_SPIKE:
      return decodeVolumeSpike(data, base);
    case ALPHA_TYPE.PRICE_MOMENTUM:
      return decodePriceMomentum(data, base);
    default:
      return {
        ...base,
        alphaType,
        alphaTypeName: ALPHA_TYPE_NAME[alphaType] || "UNKNOWN",
        raw: data.slice(5).toString("hex"),
      };
  }
}

/**
 * Decode WHALE_MOVE alpha
 */
function decodeWhaleMove(data, base) {
  return {
    ...base,
    alphaType: ALPHA_TYPE.WHALE_MOVE,
    alphaTypeName: "WHALE_MOVE",
    direction: data[6],
    directionName: DIRECTION_NAME[data[6]] || "UNKNOWN",
    tokenMint: new PublicKey(data.slice(7, 39)).toBase58(),
    amountLamports: data.readBigUInt64LE(39),
    amountSol: Number(data.readBigUInt64LE(39)) / 1e9,
    whaleWallet: new PublicKey(data.slice(47, 79)).toBase58(),
    timestamp: Number(data.readBigInt64LE(79)),
    txSignature: data.slice(87, 119).toString("utf8").replace(/\0/g, ""),
  };
}

/**
 * Decode VOLUME_SPIKE alpha
 */
function decodeVolumeSpike(data, base) {
  return {
    ...base,
    alphaType: ALPHA_TYPE.VOLUME_SPIKE,
    alphaTypeName: "VOLUME_SPIKE",
    direction: data[6],
    directionName: DIRECTION_NAME[data[6]] || "UNKNOWN",
    tokenMint: new PublicKey(data.slice(7, 39)).toBase58(),
    currentVolume: data.readBigUInt64LE(39),
    avgVolume: data.readBigUInt64LE(47),
    spikeMultiplier: data.readUInt16LE(55),
    spikeMultiplierX: (data.readUInt16LE(55) / 100).toFixed(1) + "x",
    periodSeconds: Number(data.readBigUInt64LE(57)),
    timestamp: Number(data.readBigInt64LE(65)),
  };
}

/**
 * Decode PRICE_MOMENTUM alpha
 */
function decodePriceMomentum(data, base) {
  return {
    ...base,
    alphaType: ALPHA_TYPE.PRICE_MOMENTUM,
    alphaTypeName: "PRICE_MOMENTUM",
    direction: data[6],
    directionName: DIRECTION_NAME[data[6]] || "UNKNOWN",
    tokenMint: new PublicKey(data.slice(7, 39)).toBase58(),
    priceNow: data.readBigUInt64LE(39),
    priceBefore: data.readBigUInt64LE(47),
    changeBps: data.readInt16LE(55),
    changePercent: (data.readInt16LE(55) / 100).toFixed(2) + "%",
    momentumScore: data.readUInt16LE(57),
    lookbackSeconds: Number(data.readBigUInt64LE(59)),
    timestamp: Number(data.readBigInt64LE(67)),
  };
}

/**
 * Decode SIGNAL message
 */
function decodeSignal(data, base) {
  return {
    ...base,
    tokenMint: new PublicKey(data.slice(5, 37)).toBase58(),
    sentiment: data[37],
    momentum: data[38],
    risk: data[39],
    confidence: data[40],
    priceNow: data.readBigUInt64LE(41),
    priceTarget: data.readBigUInt64LE(49),
    timeframeSeconds: Number(data.readBigUInt64LE(57)),
    timestamp: Number(data.readBigInt64LE(65)),
  };
}

/**
 * Decode RALLY message
 */
function decodeRally(data, base) {
  return {
    ...base,
    tokenMint: new PublicKey(data.slice(5, 37)).toBase58(),
    action: data[37],
    actionName: data[37] === 0 ? "BUY" : "SELL",
    entryPrice: data.readBigUInt64LE(38),
    targetPrice: data.readBigUInt64LE(46),
    stopPrice: data.readBigUInt64LE(54),
    startTime: Number(data.readBigInt64LE(62)),
    maxDurationSeconds: Number(data.readBigUInt64LE(70)),
    rallyId: Number(data.readBigUInt64LE(78)),
    timestamp: Number(data.readBigInt64LE(86)),
  };
}

/**
 * Decode EXIT message
 */
function decodeExit(data, base) {
  const exitTypes = ["TARGET_HIT", "STOP_HIT", "TIME_EXPIRED", "MANUAL"];
  return {
    ...base,
    rallyId: Number(data.readBigUInt64LE(5)),
    exitType: data[13],
    exitTypeName: exitTypes[data[13]] || "UNKNOWN",
    exitPrice: data.readBigUInt64LE(14),
    timestamp: Number(data.readBigInt64LE(22)),
  };
}

/**
 * Decode RESULT message
 */
function decodeResult(data, base) {
  const outcomes = ["WIN", "LOSS", "BREAKEVEN"];
  return {
    ...base,
    rallyId: Number(data.readBigUInt64LE(5)),
    tokenMint: new PublicKey(data.slice(13, 45)).toBase58(),
    entryPrice: data.readBigUInt64LE(45),
    exitPrice: data.readBigUInt64LE(53),
    outcome: data[61],
    outcomeName: outcomes[data[61]] || "UNKNOWN",
    pnlBps: data.readInt16LE(62),
    pnlPercent: (data.readInt16LE(62) / 100).toFixed(2) + "%",
    participants: data[64],
    durationSeconds: Number(data.readBigUInt64LE(65)),
    timestamp: Number(data.readBigInt64LE(73)),
  };
}

/**
 * Pretty print a decoded message (for logging)
 */
export function prettyPrint(decoded) {
  if (!decoded) return "[NOT A CHUM MESSAGE]";

  const time = new Date(decoded.timestamp * 1000).toISOString();
  let out = `\n╔═══ CHUM CLOUD ${decoded.msgTypeName} ═══╗\n`;
  out += `║ Agent: ${decoded.agentName}\n`;
  out += `║ Time:  ${time}\n`;

  switch (decoded.msgType) {
    case MSG_TYPE.ALPHA:
      out += `║ Alpha: ${decoded.alphaTypeName}\n`;
      out += `║ Direction: ${decoded.directionName}\n`;
      out += `║ Token: ${decoded.tokenMint}\n`;

      if (decoded.alphaType === ALPHA_TYPE.WHALE_MOVE) {
        out += `║ Amount: ${decoded.amountSol.toFixed(2)} SOL\n`;
        out += `║ Whale: ${decoded.whaleWallet}\n`;
      } else if (decoded.alphaType === ALPHA_TYPE.VOLUME_SPIKE) {
        out += `║ Spike: ${decoded.spikeMultiplierX}\n`;
      } else if (decoded.alphaType === ALPHA_TYPE.PRICE_MOMENTUM) {
        out += `║ Change: ${decoded.changePercent}\n`;
        out += `║ Momentum: ${decoded.momentumScore}/10000\n`;
      }
      break;

    case MSG_TYPE.SIGNAL:
      out += `║ Token: ${decoded.tokenMint}\n`;
      out += `║ Sentiment: ${decoded.sentiment}/100\n`;
      out += `║ Momentum: ${decoded.momentum}/100\n`;
      out += `║ Risk: ${decoded.risk}/100\n`;
      out += `║ Confidence: ${decoded.confidence}/100\n`;
      break;

    case MSG_TYPE.RALLY:
      out += `║ Token: ${decoded.tokenMint}\n`;
      out += `║ Action: ${decoded.actionName}\n`;
      out += `║ Rally ID: ${decoded.rallyId}\n`;
      out += `║ Duration: ${decoded.maxDurationSeconds}s\n`;
      break;

    case MSG_TYPE.EXIT:
      out += `║ Rally ID: ${decoded.rallyId}\n`;
      out += `║ Exit: ${decoded.exitTypeName}\n`;
      break;

    case MSG_TYPE.RESULT:
      out += `║ Rally ID: ${decoded.rallyId}\n`;
      out += `║ Outcome: ${decoded.outcomeName}\n`;
      out += `║ P&L: ${decoded.pnlPercent}\n`;
      out += `║ Participants: ${decoded.participants}\n`;
      break;
  }

  out += `╚${"═".repeat(35)}╝`;
  return out;
}
