import { PublicKey } from "@solana/web3.js";
import { AGENT_ID, DIRECTION } from "./utils/protocol.js";
import {
  encodeWhaleMove,
  encodeVolumeSpike,
  encodePriceMomentum,
  encodeSignal,
  encodeRally,
  encodeExit,
  encodeResult,
} from "./utils/encoder.js";
import { isChumMessage, decode, prettyPrint } from "./utils/decoder.js";

// ═══════════════════════════════════════════
// ENCODE / DECODE TEST
// ═══════════════════════════════════════════
// Verifies all message types encode and decode correctly
// Run: npm run decode

console.log("╔═══════════════════════════════════════════╗");
console.log("║    CHUM CLOUD — ENCODE/DECODE TEST        ║");
console.log("╚═══════════════════════════════════════════╝\n");

const TEST_MINT = "So11111111111111111111111111111111111111112";
const TEST_WALLET = "11111111111111111111111111111111";
const NOW = Math.floor(Date.now() / 1000);

// Test 1: Whale Move
console.log("=== TEST 1: WHALE MOVE ===");
const whaleMsg = encodeWhaleMove(AGENT_ID.WHALE_WATCHER, {
  direction: DIRECTION.BULLISH,
  tokenMint: TEST_MINT,
  amountLamports: 500_000_000_000n, // 500 SOL
  whaleWallet: TEST_WALLET,
  txSignature: "abc123",
  timestamp: NOW,
});
console.log(`Encoded: ${whaleMsg.length} bytes`);
console.log(`Hex: ${whaleMsg.toString("hex").slice(0, 40)}...`);
console.log(`Is CHUM: ${isChumMessage(whaleMsg)}`);
console.log(prettyPrint(decode(whaleMsg)));
console.log();

// Test 2: Volume Spike
console.log("=== TEST 2: VOLUME SPIKE ===");
const volumeMsg = encodeVolumeSpike(AGENT_ID.VOLUME_SCANNER, {
  direction: DIRECTION.BULLISH,
  tokenMint: TEST_MINT,
  currentVolume: 15000n,
  avgVolume: 3000n,
  spikeMultiplier: 500, // 5x
  periodSeconds: 300,
  timestamp: NOW,
});
console.log(`Encoded: ${volumeMsg.length} bytes`);
console.log(`Is CHUM: ${isChumMessage(volumeMsg)}`);
console.log(prettyPrint(decode(volumeMsg)));
console.log();

// Test 3: Price Momentum
console.log("=== TEST 3: PRICE MOMENTUM ===");
const momentumMsg = encodePriceMomentum(AGENT_ID.MOMENTUM_TRACKER, {
  direction: DIRECTION.BEARISH,
  tokenMint: TEST_MINT,
  priceNow: 89_000_000_000n, // $89 in lamport scale
  priceBefore: 95_000_000_000n, // $95
  changeBps: -631, // -6.31%
  momentumScore: 7500,
  lookbackSeconds: 900,
  timestamp: NOW,
});
console.log(`Encoded: ${momentumMsg.length} bytes`);
console.log(`Is CHUM: ${isChumMessage(momentumMsg)}`);
console.log(prettyPrint(decode(momentumMsg)));
console.log();

// Test 4: Signal
console.log("=== TEST 4: SIGNAL ===");
const signalMsg = encodeSignal(AGENT_ID.WHALE_WATCHER, {
  tokenMint: TEST_MINT,
  sentiment: 75,
  momentum: 82,
  risk: 40,
  confidence: 68,
  priceNow: 91_000_000_000n,
  priceTarget: 110_000_000_000n,
  timeframeSeconds: 86400,
  timestamp: NOW,
});
console.log(`Encoded: ${signalMsg.length} bytes`);
console.log(`Is CHUM: ${isChumMessage(signalMsg)}`);
console.log(prettyPrint(decode(signalMsg)));
console.log();

// Test 5: Rally
console.log("=== TEST 5: RALLY ===");
const rallyMsg = encodeRally(AGENT_ID.VOLUME_SCANNER, {
  tokenMint: TEST_MINT,
  action: 0, // BUY
  entryPrice: 91_000_000_000n,
  targetPrice: 100_000_000_000n,
  stopPrice: 85_000_000_000n,
  startTime: BigInt(NOW),
  maxDurationSeconds: 3600,
  rallyId: 1n,
  timestamp: NOW,
});
console.log(`Encoded: ${rallyMsg.length} bytes`);
console.log(`Is CHUM: ${isChumMessage(rallyMsg)}`);
console.log(prettyPrint(decode(rallyMsg)));
console.log();

// Test 6: Exit
console.log("=== TEST 6: EXIT ===");
const exitMsg = encodeExit(AGENT_ID.VOLUME_SCANNER, {
  rallyId: 1n,
  exitType: 0, // TARGET_HIT
  exitPrice: 100_500_000_000n,
  timestamp: NOW,
});
console.log(`Encoded: ${exitMsg.length} bytes`);
console.log(`Is CHUM: ${isChumMessage(exitMsg)}`);
console.log(prettyPrint(decode(exitMsg)));
console.log();

// Test 7: Result
console.log("=== TEST 7: RESULT ===");
const resultMsg = encodeResult(AGENT_ID.VOLUME_SCANNER, {
  rallyId: 1n,
  tokenMint: TEST_MINT,
  entryPrice: 91_000_000_000n,
  exitPrice: 100_500_000_000n,
  outcome: 0, // WIN
  pnlBps: 1044, // +10.44%
  participants: 7,
  durationSeconds: 2700,
  timestamp: NOW,
});
console.log(`Encoded: ${resultMsg.length} bytes`);
console.log(`Is CHUM: ${isChumMessage(resultMsg)}`);
console.log(prettyPrint(decode(resultMsg)));
console.log();

// Show what a human sees vs what an agent sees
console.log("═══════════════════════════════════════════");
console.log("WHAT A HUMAN SEES ON SOLANA EXPLORER:");
console.log("═══════════════════════════════════════════");
console.log(`Memo: ${whaleMsg.toString("hex")}`);
console.log("\n(Meaningless hex noise)\n");

console.log("═══════════════════════════════════════════");
console.log("WHAT AN AGENT DECODES:");
console.log("═══════════════════════════════════════════");
console.log(prettyPrint(decode(whaleMsg)));
console.log();
console.log("The room is open. The machines are talking.");
