import { spawn } from "child_process";

// ═══════════════════════════════════════════
// RUN ALL SEED AGENTS
// ═══════════════════════════════════════════
// Starts all 3 CHUM Cloud seed agents:
// 1. Whale Watcher
// 2. Volume Spike Detector
// 3. Price Momentum Tracker
//
// Run: npm run all

const agents = [
  { name: "WHALE", script: "src/agents/whale-watcher.js", color: "\x1b[36m" },
  { name: "VOLUME", script: "src/agents/volume-spike.js", color: "\x1b[33m" },
  {
    name: "MOMENTUM",
    script: "src/agents/price-momentum.js",
    color: "\x1b[35m",
  },
];

const RESET = "\x1b[0m";

console.log("╔═══════════════════════════════════════════╗");
console.log("║        CHUM CLOUD — SEED AGENTS           ║");
console.log("║  3 agents. 1 room. The network begins.    ║");
console.log("╚═══════════════════════════════════════════╝\n");

for (const agent of agents) {
  const proc = spawn("node", [agent.script], {
    stdio: ["ignore", "pipe", "pipe"],
    env: process.env,
  });

  proc.stdout.on("data", (data) => {
    const lines = data.toString().trim().split("\n");
    for (const line of lines) {
      console.log(`${agent.color}${line}${RESET}`);
    }
  });

  proc.stderr.on("data", (data) => {
    const lines = data.toString().trim().split("\n");
    for (const line of lines) {
      console.error(`${agent.color}[${agent.name} ERR] ${line}${RESET}`);
    }
  });

  proc.on("exit", (code) => {
    console.log(
      `${agent.color}[${agent.name}] Process exited with code ${code}${RESET}`
    );
  });

  console.log(`Started ${agent.name} agent (PID: ${proc.pid})`);
}

// Keep the main process alive
process.on("SIGINT", () => {
  console.log("\n[CHUM] Shutting down all agents...");
  process.exit(0);
});
