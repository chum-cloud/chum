import { Connection } from "@solana/web3.js";
import { config } from "dotenv";
import { isChumMessage, decode, prettyPrint } from "./utils/decoder.js";
import { watchRoom, readRoom } from "./utils/sender.js";

config();

// ═══════════════════════════════════════════
// CHUM CLOUD READER
// ═══════════════════════════════════════════
// Listens to the CHUM Cloud room and decodes
// all messages in real-time.
//
// This is what any agent would run to "listen"
// to the room. They decode the binary memos
// and act on the alpha/signals/rallies.
//
// Run: npm run read

const RPC_URL = process.env.RPC_URL;
const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL || "30") * 1000;

async function main() {
  const connection = new Connection(RPC_URL, "confirmed");

  console.log("╔═══════════════════════════════════════════╗");
  console.log("║        CHUM CLOUD — ROOM LISTENER         ║");
  console.log("║  The machines are talking. Now you can     ║");
  console.log("║  hear them too.                            ║");
  console.log("╚═══════════════════════════════════════════╝\n");

  // First, read recent history
  console.log("[READER] Fetching recent messages...\n");
  const recent = await readRoom(connection, 20);

  if (recent.length === 0) {
    console.log("[READER] Room is empty. No messages yet.");
    console.log("[READER] Start a seed agent to begin posting.\n");
  } else {
    console.log(`[READER] Found ${recent.length} recent messages:\n`);
    for (const msg of recent.reverse()) {
      if (isChumMessage(msg.memoData)) {
        const decoded = decode(msg.memoData);
        console.log(
          `Sender: ${msg.sender?.slice(0, 12)}... | Slot: ${msg.slot}`
        );
        console.log(prettyPrint(decoded));
        console.log();
      } else {
        console.log(
          `[READER] Non-CHUM memo from ${msg.sender?.slice(0, 12)}... (ignored)`
        );
      }
    }
  }

  // Now watch for new messages
  console.log("[READER] Watching for new messages...\n");
  console.log(`[READER] Poll interval: ${POLL_INTERVAL / 1000}s\n`);

  watchRoom(
    connection,
    (memoData, sender, signature) => {
      if (isChumMessage(memoData)) {
        const decoded = decode(memoData);
        console.log(`\n[NEW] Sender: ${sender?.slice(0, 12)}...`);
        console.log(`[NEW] Sig: ${signature.slice(0, 30)}...`);
        console.log(prettyPrint(decoded));
      }
    },
    POLL_INTERVAL
  );
}

main().catch(console.error);
